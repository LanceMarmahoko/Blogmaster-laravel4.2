@extends('_templates.master')
@section('content')
    {{$error}}
@stop
