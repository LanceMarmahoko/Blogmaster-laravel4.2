<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Blogmaster v.1</title>
{{HTML::style("css/bootstrap.css")}}
{{HTML::style("css/styles.css")}}
{{HTML::style("packages/ckeditor/contents.css")}}
</head>
<body>
