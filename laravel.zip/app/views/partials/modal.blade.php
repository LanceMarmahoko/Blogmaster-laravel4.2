<div class="modal-dialog"> 
    <div class="modal-content"> 
        <div class="modal-title"><h3>...</h3></div> 
        <div class="modal-body"><p>...</p></div> 
        <div class="modal-footer"> 
            <button type="button" class="btn btn-default modal-cancel" data-dismiss="modal">...</button>
            <button type="button" class="btn btn-danger modal-danger" id="confirm">...</button>
        </div>
    </div>
</div>